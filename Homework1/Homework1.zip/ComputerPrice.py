

screenPrice = float(input("Enter the computer screen price: "))

powerSupplyPrice = float(input("Enter the power supply price: "))

keyboardPrice = float(input("Enter the keyboard price: "))

mousePrice = float(input("Enter the mouse price: "))

totalPrice = screenPrice + powerSupplyPrice + keyboardPrice + mousePrice

print("The total price of the computer is: " + str(totalPrice) + " GEL")
