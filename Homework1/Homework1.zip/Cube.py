



cubeSideLength = float(input("Enter cube side length: "))

cubeArea = 6 * cubeSideLength ** 2

cubeVolume = cubeSideLength ** 3

print("Cube area is: " + str(cubeArea))
print("Cube volume is: " + str(cubeVolume))