




number1 = int(input("Enter number 1: "))
number2 = int(input("Enter number 2: "))
number3 = int(input("Enter number 3: "))

sum = number1 + number2 + number3

print("The sum is: " + str(sum))
